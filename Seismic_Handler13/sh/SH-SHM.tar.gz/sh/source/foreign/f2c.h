
/* file f2c.h
 *      =====
 *
 * version 2, 4-Jan-2007
 *
 * prototypes of f2c routines (automatically translated routines FORTRAN -> C)
 * K. Stammler, 12-Dec-94
 */



int dcomp6_(long *lb, char *ibuf, int *lout, long iout[], int *ierror,
	int ibuf_len);
int intand_( int *i1, int *i2, int *i3 );
