
/* file sysext.h
 *      ========
 *
 * version 1, 22-Jul-94
 *
 * some missing prototypes of system services
 * K. Stammler, 22-Jul-94
 */



/* int system( char cmd[] ); */
/* int unlink( char path[] ); */
