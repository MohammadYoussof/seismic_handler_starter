c * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
c
c        c o m m o n    a r e a    n u m c o n
c
c * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

c  SccsId:  @(#)numcon.h	36.1  3/6/89
      common/numcon/dpd2r ,dpr2d ,chisq ,dg2km ,dg2rd ,km2dg ,pi    ,
     *              radeth,rd2dg ,szmax ,szmin ,twopi ,znorm
      real*8    dpd2r ,dpr2d
      real*4    chisq ,dg2km ,dg2rd ,km2dg ,pi    ,radeth,rd2dg ,
     *          szmax ,szmin ,twopi ,znorm
