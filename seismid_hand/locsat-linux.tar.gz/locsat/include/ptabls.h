
c    Common block used by tttab for creting travel-time tables

c SccsId:  @(#)ptabls.h	36.1	3/6/89

      common/ptabls/depth ( 9),dfeth (19),feth  (19),dpth  (56)
     *             ,tpth(56,9),hvvth(17,2),istdth(50),idisth(50)
c      integer*2 istdth,idisth
